hippopotomonstrosesquippedaliophobia.exe by snare
(i'm back)


this is a malware, that i spent so much weeks. running on actual hardware will destroy this pc and you're gonna pay for damages. only VMware that can destroy your own vm, but,
it doesn't destroy your actual pc when you are vm.
i'm lazy to make my apps run on windows xp.